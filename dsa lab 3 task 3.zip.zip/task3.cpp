#include <iostream>
#include "abstractarray.h"
#include "stack.h"

using namespace std;

bool is_prime(int n) 
{
    if (n <= 1) return false;
    for (int i = 2; i <= sqrt(n); i++)
    {
        if (n % i == 0) return false;
    }
    return true;
}

bool is_perfect_square(int n) 

{
    if (n < 0) return false;
    int root = sqrt(n);
    return (root * root == n);
}

bool is_palindrome_number(int n)
{
    int temp = n, reversed = 0, rem;
    while (temp > 0) 
    {
        rem = temp % 10;
        reversed = reversed * 10 + rem;
        temp /= 10;
    }
    return (n == reversed);
}

bool check_stack_palindrome(int arr[], int n)
{
    for (int i = 0; i < n / 2; i++) 
    
    {
        if (arr[i] != arr[n - 1 - i]) 
            return false;
    }
    return true;
}

int main() 
{
    int size = 10;
    abstract_array* s = new stack(size);
    int temp_arr[10];

    for (int i = 0; i < size; i++) 
    {
        int val;
        cout << "enter integer " << i + 1 << ": ";
        cin >> val;
        s->add(val);
        temp_arr[i] = val;
    }

    cout << "\nindividual checks for stack values:" << endl;
    int current_val;
    int index = size - 1;
    while (s->get(0, current_val))
    {
        cout << "value: " << current_val;
        if (is_prime(current_val)) cout << " | prime";
        if (is_perfect_square(current_val)) cout << " | perfect square";
        if (is_palindrome_number(current_val)) cout << " | palindrome number";
        cout << endl;
    }

    if (check_stack_palindrome(temp_arr, size)) 
    {
        cout << "\nthe stack values form a palindrome" << endl;
    }
    else 
    {
        cout << "\nthe stack values do not form a palindrome" << endl;
    }

    delete s;
    return 0;
}