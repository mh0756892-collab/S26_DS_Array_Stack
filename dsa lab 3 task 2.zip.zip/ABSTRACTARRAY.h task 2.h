#pragma once
#ifndef abstractarray_h
#define abstractarray_h

class abstract_array 
{
protected:
    int current_index;
    int* values;
    int max_capacity;

public:
    abstract_array(int max_capacity = 0) 
    {
        current_index = -1;
        max_capacity = max_capacity;
        values = new int[max_capacity] {0};
    }

    virtual void add(int v) = 0;
    virtual bool get(int index, int& value) = 0;

    bool is_empty()
    {
        return (current_index < 0);
    }

    bool is_full()
    {
        return (current_index == max_capacity - 1);
    }
};

#endif
